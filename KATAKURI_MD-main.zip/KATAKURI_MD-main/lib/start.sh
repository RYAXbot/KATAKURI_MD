while true
do
echo "Starting WASI-Md!"
node .
done
